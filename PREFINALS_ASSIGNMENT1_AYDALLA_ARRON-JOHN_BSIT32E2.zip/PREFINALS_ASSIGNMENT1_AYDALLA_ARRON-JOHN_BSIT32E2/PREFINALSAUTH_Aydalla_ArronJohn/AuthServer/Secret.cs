﻿namespace AuthServer
{
    public static class Secret
    {
        public const string SecretKey = "Alphabetical";//"your_strong_random_secret_key_here"
    }
}
