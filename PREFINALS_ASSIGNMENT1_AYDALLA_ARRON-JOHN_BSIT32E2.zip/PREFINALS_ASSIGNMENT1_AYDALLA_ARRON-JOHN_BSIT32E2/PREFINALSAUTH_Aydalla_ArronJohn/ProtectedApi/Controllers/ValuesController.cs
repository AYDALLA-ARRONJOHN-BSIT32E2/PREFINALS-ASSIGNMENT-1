﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace ProtectedApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ValuesController : ControllerBase
    {
        [HttpGet]
        [Authorize]
        public IActionResult Get()
        {
            
            var userInfo = new
            {
                Name = "Arron John Aydalla",
                Section = "BSIT32E2",
                Course = "Infortmation Technology"
            };

            var funFacts = new[]
            {
                "I like dancing!",
                "Im playing League of Legends.",
                "I like watching kpop.",
            };

            return Ok(new { UserInfo = userInfo, FunFacts = funFacts });
        }
    }
}
